import json

for subset in ["train","dev"]:
    
    f_json = open(f"./json/{subset}.json","r")
    data = json.load(f_json)
    f_json.close()

    f_out = open(f"./tsv/{subset}.tsv","w")

    f_out.write(
        "id" + "\t" +
        "question" + "\t" +
        "answers.a" + "\t" +
        "answers.b" + "\t" +
        "answers.c" + "\t" +
        "answers.d" + "\t" +
        "answers.e" + "\t" +
        "correct_answers" + "\t"
        "nbr_correct_answers" + "\n"
    )
    
    for d in data:

        f_out.write(
            d["id"] + "\t" +
            d["question"] + "\t" +
            d["answers"]["a"] + "\t" +
            d["answers"]["b"] + "\t" +
            d["answers"]["c"] + "\t" +
            d["answers"]["d"] + "\t" +
            d["answers"]["e"] + "\t" +
            "|".join(d["correct_answers"]) + "\t" +
            str(d["nbr_correct_answers"]) + "\n"
        )
    
    f_out.close()
    