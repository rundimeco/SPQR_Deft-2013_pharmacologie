# coding=utf-8
# Copyright 2020 The HuggingFace Datasets Authors and the current dataset script contributor.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""FrenchMedMCQA : A French Multiple-Choice Question Answering Corpus for Medical domain"""

import os
import json

import datasets

_DESCRIPTION = """\
FrenchMedMCQA
"""

_HOMEPAGE = "https://frenchmedmcqa.github.io"

_LICENSE = "Apache License 2.0"

_CITATION = """\
@unpublished{labrak:hal-03824241,
  TITLE = {{FrenchMedMCQA: A French Multiple-Choice Question Answering Dataset for Medical domain}},
  AUTHOR = {Labrak, Yanis and Bazoge, Adrien and Dufour, Richard and Daille, Béatrice and Gourraud, Pierre-Antoine and Morin, Emmanuel and Rouvier, Mickael},
  URL = {https://hal.archives-ouvertes.fr/hal-03824241},
  NOTE = {working paper or preprint},
  YEAR = {2022},
  MONTH = Oct,
  PDF = {https://hal.archives-ouvertes.fr/hal-03824241/file/LOUHI_2022___QA-3.pdf},
  HAL_ID = {hal-03824241},
  HAL_VERSION = {v1},
}
"""

class DEFT2023(datasets.GeneratorBasedBuilder):
    """FrenchMedMCQA : A French Multi-Choice Question Answering Corpus for Medical domain"""

    VERSION = datasets.Version("1.0.0")

    def _info(self):

        features = datasets.Features(
            {
                "id": datasets.Value("string"),
                "question": datasets.Value("string"),
                "answer_a": datasets.Value("string"),
                "answer_b": datasets.Value("string"),
                "answer_c": datasets.Value("string"),
                "answer_d": datasets.Value("string"),
                "answer_e": datasets.Value("string"),
                "correct_answers": datasets.Sequence(
                    datasets.features.ClassLabel(names=["a", "b", "c", "d", "e"]),
                ),
                "type": datasets.Value("string"),
                "subject_name": datasets.Value("string"),
                "number_correct_answers": datasets.features.ClassLabel(names=["1","2","3","4","5"]),
            }
        )
        
        return datasets.DatasetInfo(
            description=_DESCRIPTION,
            features=features,
            homepage=_HOMEPAGE,
            license=_LICENSE,
            citation=_CITATION,
        )

    def _split_generators(self, dl_manager):
        """Returns SplitGenerators."""

        return [
            datasets.SplitGenerator(
                name=datasets.Split.TRAIN,
                gen_kwargs={
                    "filepath": os.path.join("../json/", "train.json"),
                },
            ),
            datasets.SplitGenerator(
                name=datasets.Split.VALIDATION,
                gen_kwargs={
                    "filepath": os.path.join("../json/", "dev.json"),
                },
            ),
            # datasets.SplitGenerator(
            #     name=datasets.Split.TEST,
            #     gen_kwargs={
            #         "filepath": os.path.join("../json/", "test.json"),
            #     },
            # ),
        ]

    def _generate_examples(self, filepath):

        with open(filepath, encoding="utf-8") as f:

            data = json.load(f)

            for key, d in enumerate(data):

                yield key, {
                    "id": d["id"],
                    "question": d["question"],
                    "answer_a": d["answers"]["a"],
                    "answer_b": d["answers"]["b"],
                    "answer_c": d["answers"]["c"],
                    "answer_d": d["answers"]["d"],
                    "answer_e": d["answers"]["e"],
                    "correct_answers": d["correct_answers"],
                    "number_correct_answers": str(len(d["correct_answers"])),
                    "type": d["type"],
                    "subject_name": d["subject_name"],
                }
