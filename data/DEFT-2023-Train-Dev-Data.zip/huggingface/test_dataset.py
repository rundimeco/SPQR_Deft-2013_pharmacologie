from datasets import load_dataset

dataset = load_dataset("./DEFT2023.py")

print("#"*50)
print(dataset)
print("#"*50)
print(dataset["train"])
print("#"*50)
print(dataset["train"][0])
print("#"*50)

print(dataset["train"].features["number_correct_answers"].names)

label_list = dataset["train"].features["correct_answers"].feature.names
print(label_list)
